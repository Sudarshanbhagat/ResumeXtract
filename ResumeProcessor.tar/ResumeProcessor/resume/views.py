from rest_framework.views import APIView
from rest_framework.response import Response
from pdfminer.high_level import extract_text
from docx import Document
import re

class ResumeExtractionView(APIView):
    def post(self, request, *args, **kwargs):
        print("Request received!")  # Debug: Confirm the request reached the view

        # Check if a file is uploaded
        file = request.FILES.get('file')
        if not file:
            print("No file uploaded!")  # Debug: Log if no file is provided
            return Response({"error": "No file uploaded"}, status=400)

        print(f"Uploaded file name: {file.name}")  # Debug: Log the file name

        try:
            # Process the file
            if file.name.endswith('.pdf'):
                print("Processing a PDF file...")  # Debug: Log file type
                text = extract_text(file)
            elif file.name.endswith('.docx'):
                print("Processing a DOCX file...")  # Debug: Log file type
                document = Document(file)
                text = '\n'.join([para.text for para in document.paragraphs])
            else:
                print("Unsupported file format!")  # Debug: Log unsupported file types
                return Response({"error": "Unsupported file format"}, status=400)

            # Debug: Log extracted text
            print(f"Extracted text:\n{text[:500]}")  # Print the first 500 characters

            # Extract details using regex
            first_name = re.search(r'\b[A-Z][a-z]*\b', text).group() if re.search(r'\b[A-Z][a-z]*\b', text) else "Unknown"
            email = re.search(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', text).group() if re.search(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', text) else "Unknown"
            mobile_number = re.search(r'\b\d{10}\b', text).group() if re.search(r'\b\d{10}\b', text) else "Unknown"

            # Debug: Log extracted details
            print(f"Extracted Details:\nFirst Name: {first_name}, Email: {email}, Mobile: {mobile_number}")

            # Return extracted data
            return Response({
                "first_name": first_name,
                "email": email,
                "mobile_number": mobile_number,
            }, status=200)
        except Exception as e:
            print(f"Error during processing: {e}")  # Debug: Log exceptions
            return Response({"error": str(e)}, status=500)
