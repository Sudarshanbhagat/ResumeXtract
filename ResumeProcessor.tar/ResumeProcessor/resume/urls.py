from django.urls import path
from .views import ResumeExtractionView

urlpatterns = [
    path('', ResumeExtractionView.as_view(), name='extract_resume'),
]
