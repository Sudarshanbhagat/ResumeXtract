import re
from pdfminer.high_level import extract_text
from docx import Document

def parse_resume(file):
    # Extract text based on file type
    if file.name.endswith('.pdf'):
        text = extract_text(file)
    elif file.name.endswith('.docx'):
        document = Document(file)
        text = '\n'.join([para.text for para in document.paragraphs])
    else:
        raise ValueError("Unsupported file format")

    # Extract first name (basic regex for demonstration)
    first_name_match = re.search(r'\b[A-Z][a-z]*\b', text)
    first_name = first_name_match.group() if first_name_match else "Unknown"

    # Extract email
    email_match = re.search(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', text)
    email = email_match.group() if email_match else "Unknown"

    # Extract mobile number (basic regex for demonstration)
    mobile_match = re.search(r'\b\d{10}\b', text)
    mobile_number = mobile_match.group() if mobile_match else "Unknown"

    return {
        "first_name": first_name,
        "email": email,
        "mobile_number": mobile_number,
    }
