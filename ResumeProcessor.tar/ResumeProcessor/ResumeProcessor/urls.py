from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/extract_resume/', include('resume.urls')),  # Include app-specific URLs
]
